//
//  BestGroupModel.m
//  BaseProject
//
//  Created by jiyingxin on 15/11/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BestGroupModel.h"

@implementation BestGroupModel

@end
