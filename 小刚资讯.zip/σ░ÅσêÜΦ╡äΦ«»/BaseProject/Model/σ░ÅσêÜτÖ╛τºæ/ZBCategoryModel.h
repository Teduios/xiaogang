//
//  ZBCategoryModel.h
//  BaseProject
//
//  Created by jiyingxin on 15/11/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@interface ZBCategoryModel : BaseModel

@property (nonatomic, copy) NSString *tag;
@property (nonatomic, copy) NSString *text;

@end


