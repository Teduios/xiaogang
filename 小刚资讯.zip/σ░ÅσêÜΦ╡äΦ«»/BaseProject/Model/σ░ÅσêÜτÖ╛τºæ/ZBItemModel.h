//
//  ZBItemModel.h
//  BaseProject
//
//  Created by jiyingxin on 15/11/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@interface ZBItemModel : BaseModel
@property (nonatomic, assign) NSInteger ID;
@property (nonatomic, copy) NSString *text;
@end


