//
//  XiMaAlbumViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"

@interface XiMaAlbumViewModel : BaseViewModel

@end
